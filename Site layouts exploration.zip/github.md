repo: rafaortman/filmcurator
branch: main

## Last sync
date: 2026-08-01T13:03:32Z

### Updated in this project
- Copied index.html, app.js, data.js unmodified (structure/logic untouched)
- Added 3 restyled layout variants (CSS-only): layout-cinema.html, layout-editorial.html, layout-poster.html

## Screen map
| Screen | Source files |
|---|---|
| layout-cinema.html | index.html (CSS only), app.js, data.js |
| layout-editorial.html | index.html (CSS only), app.js, data.js |
| layout-poster.html | index.html (CSS only), app.js, data.js |
